var class_coord_tuning =
[
    [ "CoordTuning", "class_coord_tuning.html#a3152ab10c708fd23925875b4dcb2f7ca", null ],
    [ "~CoordTuning", "class_coord_tuning.html#a8a8e4b1d00d6505918bec2843dc0e320", null ],
    [ "GetCoords", "class_coord_tuning.html#a9cd14e5b8cb49f599d2e5f1cb417f3a6", null ],
    [ "GetDeadband", "class_coord_tuning.html#a2feaa5b7a787afdf1a1c1ba160c4b9de", null ],
    [ "IsSmoothEnabled", "class_coord_tuning.html#ae537b081bd31c8be2bbfdbec8a5e66d4", null ]
];