var class_application =
[
    [ "Application", "class_application.html#afa8cc05ce6b6092be5ecdfdae44e05f8", null ],
    [ "~Application", "class_application.html#a20573928a0d53fb96d929513bc5acde6", null ],
    [ "OnProcessNotify", "class_application.html#a8f0bc49c6c169187ffd84327abca0512", null ]
];