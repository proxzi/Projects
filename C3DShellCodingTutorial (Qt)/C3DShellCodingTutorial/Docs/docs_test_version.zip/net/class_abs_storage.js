var class_abs_storage =
[
    [ "CheckReturnType", "class_abs_storage.html#a69890b46f5357665e73de6e18410e805", null ],
    [ "Invoke", "class_abs_storage.html#ada61f867ac2136c2a7b86fdea37da1de", null ]
];