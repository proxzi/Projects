var class_bool_property =
[
    [ "BoolProperty", "class_bool_property.html#a3f3143927cd62d31679ad59af0315832", null ],
    [ "~BoolProperty", "class_bool_property.html#ac176d3c7381f4e03bab1cfbe1de8b86c", null ],
    [ "_GetPropertyValue", "class_bool_property.html#a912d7c0514f66575178626ff591d00c1", null ],
    [ "GetCharValue", "class_bool_property.html#aa4568b0c34bcd1262f44bd60f4abced9", null ],
    [ "IsA", "class_bool_property.html#a52e778d541395a8ea11581dd7050abf8", null ],
    [ "SetPropertyValue", "class_bool_property.html#ab960160de5fc202994e2f0a682dfba58", null ],
    [ "value", "class_bool_property.html#a734c9b809aa9b826e5e50750dca32a04", null ]
];