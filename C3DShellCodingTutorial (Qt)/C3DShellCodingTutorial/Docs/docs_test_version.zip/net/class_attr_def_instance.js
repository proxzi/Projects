var class_attr_def_instance =
[
    [ "AttrDefInstance", "class_attr_def_instance.html#a14f1a490e4d7ff59aa26d25795636388", null ],
    [ "~AttrDefInstance", "class_attr_def_instance.html#ac1d4e7ae95865b2fd7a345b72e86aa56", null ],
    [ "GetAttrDefinition", "class_attr_def_instance.html#a5667f840d7c6e1ef4bb7a087ff506a62", null ]
];