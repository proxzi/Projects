var class_box_rep =
[
    [ "BoxRep", "class_box_rep.html#a93bd67ce568e3074c6ae0c556cb7660b", null ],
    [ "~BoxRep", "class_box_rep.html#ab154b6b7c3174eae9ef242de8ba1801a", null ],
    [ "GetHeight", "class_box_rep.html#aaafe7f77fa222e7a6c55abe505a4833a", null ],
    [ "GetLength", "class_box_rep.html#aa8b484feec67a832dfccab9727af2394", null ],
    [ "GetWidth", "class_box_rep.html#a3f03db52d37e161b3e0472deeb0c180e", null ]
];