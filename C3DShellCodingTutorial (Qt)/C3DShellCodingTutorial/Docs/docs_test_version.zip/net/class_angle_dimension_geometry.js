var class_angle_dimension_geometry =
[
    [ "TypeAngle", "class_angle_dimension_geometry.html#acc6c4f98ea69464e15a442298ef53a00", [
      [ "ta_Internal", "class_angle_dimension_geometry.html#acc6c4f98ea69464e15a442298ef53a00a64615bc1a246c9cd4c553d65b94228d6", null ],
      [ "ta_Exterior", "class_angle_dimension_geometry.html#acc6c4f98ea69464e15a442298ef53a00ad99b33a94f99ba4b934d83ec778729e6", null ]
    ] ],
    [ "AngleDimensionGeometry", "class_angle_dimension_geometry.html#a1cb8003fe120c30cd7c2b58ccceead02", null ],
    [ "~AngleDimensionGeometry", "class_angle_dimension_geometry.html#a39f2894da47de62740e5dde6f74729fd", null ],
    [ "CalculateValue", "class_angle_dimension_geometry.html#a1b563ed71f8f1ca77ee37922e68ec750", null ],
    [ "GetBoundingBox", "class_angle_dimension_geometry.html#abbd8d3875f5629942bcc872105b871f3", null ],
    [ "GetCenterPoint", "class_angle_dimension_geometry.html#af452258ea4881f9f91a72a3c244ba5fc", null ],
    [ "GetDefaultUnits", "class_angle_dimension_geometry.html#a434955bc55a1d94839dbeaa2f9f1c5e3", null ],
    [ "GetFirstPoint", "class_angle_dimension_geometry.html#ab6264de91da8f7c9bb0fe862a25b6f1e", null ],
    [ "GetOutputUnits", "class_angle_dimension_geometry.html#a942d8102692774551ad468cfb0e82754", null ],
    [ "GetSecondPoint", "class_angle_dimension_geometry.html#a87aaa6f6a08f8b11e78216b5a6b25da9", null ],
    [ "GetTextPosition", "class_angle_dimension_geometry.html#ae44edcd1b3f7b9c1502cc13c01898cc3", null ],
    [ "OpenGLDraw", "class_angle_dimension_geometry.html#a99cdfea306afa9159e4a6062c88aa11b", null ],
    [ "SetDefaultUnits", "class_angle_dimension_geometry.html#adcff6db126aeb604e1909a8df47362dd", null ],
    [ "SetMeasuredGeometry", "class_angle_dimension_geometry.html#ade9ea13ff1f7c7c5da70084b949a5bf0", null ],
    [ "SetOutputUnits", "class_angle_dimension_geometry.html#a112b51bc24ca85c237b5b10c0564121e", null ],
    [ "SetTextPosition", "class_angle_dimension_geometry.html#a37177e9c62b3344b3d620e9489a64dec", null ]
];