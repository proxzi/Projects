var class_annotation_geometry =
[
    [ "~AnnotationGeometry", "class_annotation_geometry.html#adeb36d48b2ad9c95c014a34c8a4fd82b", null ],
    [ "AnnotationGeometry", "class_annotation_geometry.html#abb9ae2898cd21cbd2223252f7a12643f", null ],
    [ "IsAnnotation", "class_annotation_geometry.html#a5acabf46952dad4ac5733da32d815ce5", null ]
];