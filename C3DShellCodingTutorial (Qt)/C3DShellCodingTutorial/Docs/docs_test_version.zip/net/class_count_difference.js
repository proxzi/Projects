var class_count_difference =
[
    [ "CountDifference", "class_count_difference.html#a3bf83cc5d69534da2551d58a948083cf", null ],
    [ "cnt1", "class_count_difference.html#aea427696fd379a4f7fb5713d6eb51b52", null ],
    [ "cnt2", "class_count_difference.html#a00a042349397dffef7b7fc6ec497bbbb", null ],
    [ "valid", "class_count_difference.html#a37170203c6bd27e8cc384ac15f4e9074", null ]
];