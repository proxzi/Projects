var class_child_event =
[
    [ "ChildEvent", "class_child_event.html#a478b64a3c149e30df627d438520434bf", null ],
    [ "~ChildEvent", "class_child_event.html#a8f63bd929e78652c76418ed0c3e43ac0", null ],
    [ "m_pObject", "class_child_event.html#ac1d0d510772f8db0089ff610c8bb77de", null ]
];