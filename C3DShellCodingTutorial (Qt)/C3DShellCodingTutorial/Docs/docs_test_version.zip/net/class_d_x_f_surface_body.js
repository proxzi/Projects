var class_d_x_f_surface_body =
[
    [ "DXFSurfaceBody", "class_d_x_f_surface_body.html#a590baafc7408e01d86b90da13bc40d2c", null ],
    [ "DXFSurfaceBody", "class_d_x_f_surface_body.html#a5e77624d7af81bb21029dc69a1fdeb6b", null ],
    [ "~DXFSurfaceBody", "class_d_x_f_surface_body.html#a6564eda791c92351591afad3328c649c", null ],
    [ "AddFace", "class_d_x_f_surface_body.html#a29289084d956c1e4dfb502ec846b5e1b", null ],
    [ "AddFaces", "class_d_x_f_surface_body.html#a0132d3883c4dcd40b21a95374db74e84", null ],
    [ "AddGrid", "class_d_x_f_surface_body.html#afa87882f56ac127a81f5042bdfef20fc", null ],
    [ "Flush", "class_d_x_f_surface_body.html#a4ab592f621258aa7feaee2780646a144", null ],
    [ "GenerateItems", "class_d_x_f_surface_body.html#adf02f4c246dfa67b76f1fd77dd1c0814", null ],
    [ "GetFacesCount", "class_d_x_f_surface_body.html#a483477aa7639418915c3047ab241af0a", null ],
    [ "GetMesh", "class_d_x_f_surface_body.html#a256bfb13765cf3f27d970e1e7df4e5ba", null ],
    [ "GetPlacement", "class_d_x_f_surface_body.html#af3cdfc91a547f9ac229ca71538b3c851", null ],
    [ "IsEmpty", "class_d_x_f_surface_body.html#a866f4fbdfccade58e9279eb4b5f4432b", null ],
    [ "IsSingle", "class_d_x_f_surface_body.html#a2b6eaca256321d56bb43420ac82e09b4", null ]
];