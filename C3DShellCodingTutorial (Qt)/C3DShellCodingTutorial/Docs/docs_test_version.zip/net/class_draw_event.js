var class_draw_event =
[
    [ "DrawEvent", "class_draw_event.html#a4c2fb262756493e112d77f7dd1102193", null ],
    [ "DrawEvent", "class_draw_event.html#a0b3c8c518d0b61e60e5b964ae048f364", null ],
    [ "~DrawEvent", "class_draw_event.html#a41315e79ae1f6b4ec719af26f5757cf1", null ],
    [ "GetRect", "class_draw_event.html#ae0506f084dd28c193a420ba8cefe4188", null ],
    [ "GetRegion", "class_draw_event.html#a437f3a6440e6ddd12e319d587e407fd0", null ],
    [ "m_erased", "class_draw_event.html#a2761ec7db87522d74ee0223e61387f54", null ],
    [ "m_rect", "class_draw_event.html#a69943627556048d179186d1d233de72c", null ],
    [ "m_region", "class_draw_event.html#a9a8b55f5160f693ec1b76e30ec7cfc68", null ]
];