var attr__color_8h =
[
    [ "__RGB__", "attr__color_8h.html#a54aa63b834bddb7c7e189623514476d6", null ],
    [ "RGB2uint32", "group___model___attributes.html#ga29fee97db3c34be1cab6343d7ec05b58", null ],
    [ "uint322RGB", "group___model___attributes.html#ga9366814c468c942930e12b74955861a7", null ]
];