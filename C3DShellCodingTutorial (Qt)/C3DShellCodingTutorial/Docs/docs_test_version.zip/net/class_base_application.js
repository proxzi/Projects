var class_base_application =
[
    [ "BaseApplication", "class_base_application.html#ab1ef66f8f9dd1496d06dcc05e24e0b92", null ],
    [ "~BaseApplication", "class_base_application.html#a5a7dbd0489d2a7cec3df298fa3f9fb9e", null ],
    [ "BaseApplication", "class_base_application.html#a82fc8de9cb7ec8f40b307ca19b5be399", null ],
    [ "CompressEvent", "class_base_application.html#a7dcbd3c2be928f851d573627f9cc0505", null ],
    [ "Initialization", "class_base_application.html#a0ec0b95733491d7944502f6af2b81e95", null ],
    [ "OnEvent", "class_base_application.html#a742db1793040fb82635c513034b04c81", null ],
    [ "OnProcessNotify", "class_base_application.html#a11a536ea267b3c36b94a48850ac283f7", null ],
    [ "WinApplication", "class_base_application.html#a8b62923e58ada427447576dc17341b69", null ],
    [ "WinApplicationPrivate", "class_base_application.html#adaad60fb203e2fbcba0cf81a9f8dafdb", null ]
];