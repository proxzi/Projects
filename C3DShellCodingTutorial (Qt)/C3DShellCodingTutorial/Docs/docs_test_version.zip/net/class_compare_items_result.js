var class_compare_items_result =
[
    [ "CompareItemsResult", "class_compare_items_result.html#a06d477e51ac9d2599effdc60128f3acc", null ],
    [ "~CompareItemsResult", "class_compare_items_result.html#ae4148601624020ccfa255613ce18d343", null ],
    [ "Add", "class_compare_items_result.html#abf77c36771b0cde425a46eac20181b87", null ],
    [ "AreItemsEqual", "class_compare_items_result.html#ac48809e3628127637d7a0f207693b3fb", null ],
    [ "GetPrimitiveDifferences", "class_compare_items_result.html#aa15ef0807299cbde370ce28e038d15fa", null ],
    [ "HaveGeometricDifferences", "class_compare_items_result.html#af482df6b6f7deed409db99a62c382809", null ],
    [ "NamesDifferencesCount", "class_compare_items_result.html#a32e185a2ee9dd4bb0509c859eecebdca", null ],
    [ "Reset", "class_compare_items_result.html#abd8f485d8fee45ed9d4a7dd0933815ba", null ],
    [ "SetItemsEqual", "class_compare_items_result.html#af8f43ce69ba82223a6eaa7e012a0b310", null ],
    [ "areItemsEqual", "class_compare_items_result.html#a1ffd211c06998cd0c9631b24be7fe96c", null ],
    [ "differences", "class_compare_items_result.html#a47b0e55fabacf7469a273b81f8ec1cf5", null ]
];