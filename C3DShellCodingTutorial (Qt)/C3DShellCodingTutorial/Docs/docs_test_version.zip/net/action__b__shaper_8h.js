var action__b__shaper_8h =
[
    [ "MbeSurfReconstructMode", "group___polygonal___objects.html#gaad998174f3210213a325f02aa5bf1b8c", [
      [ "srm_All", "group___polygonal___objects.html#ggaad998174f3210213a325f02aa5bf1b8ca696504ccafeb0d0e1d0bd586317d8150", null ],
      [ "srm_NoGrids", "group___polygonal___objects.html#ggaad998174f3210213a325f02aa5bf1b8ca8d3013e810c48bff030005090c482eda", null ],
      [ "srm_CanonicOnly", "group___polygonal___objects.html#ggaad998174f3210213a325f02aa5bf1b8ca35baeb05d97cc61fdfe8617afe6fbf43", null ],
      [ "srm_Default", "group___polygonal___objects.html#ggaad998174f3210213a325f02aa5bf1b8ca27abc5e0a400d9ec511bd3e7d6e57bbb", null ]
    ] ],
    [ "MATH_FUNC", "group___polygonal___objects.html#gac53616b00738a451d34bd262a22d0c88", null ],
    [ "MbCollection", "action__b__shaper_8h.html#ab3b5c5b3245a16c7afa99b8b03f13ffe", null ],
    [ "MbCurve3D", "action__b__shaper_8h.html#a527cc0a752bcb8fb084cfdfb5ac8d068", null ],
    [ "MbFace", "action__b__shaper_8h.html#af59e9bbe8178305b90d252e3892e6aae", null ],
    [ "MbMesh", "action__b__shaper_8h.html#ac5e01735c9a1a3b6dd2c4b2ea44c3c41", null ],
    [ "MbPlacement3D", "action__b__shaper_8h.html#a034d42c01a13da3820ded0ccca66e4fd", null ],
    [ "MbSNameMaker", "action__b__shaper_8h.html#aa8a863d55d6b75fae68ee02c9d15906e", null ],
    [ "MbSurface", "action__b__shaper_8h.html#a8477874a1dcc610dc6e63bcd8ddc962a", null ],
    [ "params", "action__b__shaper_8h.html#ab20a916346ca260b6f120b076d32eb1f", null ],
    [ "shell", "action__b__shaper_8h.html#adf7abdcf31e15c588c7081a6a07ff48c", null ]
];