var class_dimension_rep =
[
    [ "DimensionRep", "class_dimension_rep.html#a7cf1b91cabbe5baf655850ee5f0a82e0", null ],
    [ "~DimensionRep", "class_dimension_rep.html#a81305c142cac02fd7b7c8aca9063c5e2", null ],
    [ "GetDimensionColor", "class_dimension_rep.html#af28c93e95f7e47ee68a1cd0eae1dc941", null ],
    [ "GetFontSize", "class_dimension_rep.html#ab8561224f862fbcf5739af8eb9604e7e", null ],
    [ "GetLabelColor", "class_dimension_rep.html#aa62b905fc0a66ffb152b54fcd1989474", null ],
    [ "GetTextHPosition", "class_dimension_rep.html#a260379da1274bf112d765885982ff36a", null ],
    [ "GetTextOrientation", "class_dimension_rep.html#af7b5c799a40b3764ccc9151f11a4524b", null ],
    [ "GetTextVPosition", "class_dimension_rep.html#a74434078b9a54dd0e1e1260ce371db38", null ],
    [ "SetDimensionColor", "class_dimension_rep.html#abb15ac8a7cb48654204929df418517a0", null ],
    [ "SetFontSize", "class_dimension_rep.html#a3345b76e4be049267fb3e0636d52a51a", null ],
    [ "SetLabelColor", "class_dimension_rep.html#a34147dd044c5bde6f300341b6ddd79f2", null ]
];