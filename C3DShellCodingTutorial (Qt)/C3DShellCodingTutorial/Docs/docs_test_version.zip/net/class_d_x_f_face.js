var class_d_x_f_face =
[
    [ "DXFFace", "class_d_x_f_face.html#acd54586651cdba69950c23d9257d6325", null ],
    [ "~DXFFace", "class_d_x_f_face.html#a2746f9413c19889b238bc3d72b99c199", null ],
    [ "AddHole", "class_d_x_f_face.html#ae8a747a0c2fab229152ed5a226a4515f", null ],
    [ "Convert", "class_d_x_f_face.html#ad24060b1aec632297ea28849d5259e52", null ],
    [ "MakeFace", "class_d_x_f_face.html#a4d2d4d5608a735fb5865682ab455786f", null ],
    [ "MakeGrid", "class_d_x_f_face.html#a1eee8248716f396a004f1b672a41eb9f", null ],
    [ "Scale", "class_d_x_f_face.html#a0edf97076e28336b75fb22db8c4fa673", null ]
];