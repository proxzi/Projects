var class_def_range =
[
    [ "DefRange", "class_def_range.html#a3bee0cd5629276d12e75c3ffde8966cd", null ],
    [ "DefRange", "class_def_range.html#ade648d985e33c1f5538a4af164e4dbeb", null ],
    [ "Add", "class_def_range.html#a75eabff126ec51203fbc9012523a348d", null ],
    [ "Cut", "class_def_range.html#a368fb08a949b67e6ffe4462acb20bfb9", null ],
    [ "GetSet", "class_def_range.html#a2f517e4d8053ee867895608f818b3b32", null ],
    [ "HasBreaks", "class_def_range.html#adfd8bced76dd41ed6dfdb86f26a048dd", null ],
    [ "operator==", "class_def_range.html#aa977114d92f73b5153451ccfed0491b0", null ]
];