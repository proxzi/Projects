var class_diskrete_length_data =
[
    [ "DiskreteLengthData", "class_diskrete_length_data.html#a2c657004bba6a12a184d6480c87a6cba", null ],
    [ "CorrectLength", "class_diskrete_length_data.html#a469d6e2705dad0c4a9dfc067c117448a", null ],
    [ "SetFactor", "class_diskrete_length_data.html#aeeba0f49e40702eaa987ed8108beff01", null ]
];