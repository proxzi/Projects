var class_d_x_f_entity =
[
    [ "DXFEntity", "class_d_x_f_entity.html#a44d79bdbea4190d01427b6ac179aa7ad", null ],
    [ "~DXFEntity", "class_d_x_f_entity.html#a5ee8b073b113167e1a33c9ef5bbd2d91", null ],
    [ "Convert", "class_d_x_f_entity.html#a1e83d6ca42e7e580cf9c8889016622c1", null ],
    [ "SetAttributes", "class_d_x_f_entity.html#a0cc55d190bcc791650c2d564e40206c8", null ],
    [ "attributes", "class_d_x_f_entity.html#acbf18f1ac671523b6cb5fc25dc5b44c8", null ]
];