var class_cone_rep =
[
    [ "ConeRep", "class_cone_rep.html#a62862affacc19e170012658aecb98ca5", null ],
    [ "~ConeRep", "class_cone_rep.html#a26604d80dc5cb9018289a251080e3804", null ],
    [ "GetHeight", "class_cone_rep.html#a80f38e808225aac06cc0612f1c442517", null ],
    [ "GetPolygonStep", "class_cone_rep.html#a6b195f2c270eb0cf07f0f91da977a730", null ],
    [ "GetRadius", "class_cone_rep.html#a4880c2bcf2ed225be132568b52ba3b3c", null ],
    [ "SetPolygonStep", "class_cone_rep.html#a2dbc0167e3d09dbc20da6b87e339a498", null ]
];