var class_abs_write =
[
    [ "call", "class_abs_write.html#a70e705eec1387033aa70e2b8e806b62f", null ]
];