var class_d_x_f_curve =
[
    [ "DXFCurve", "class_d_x_f_curve.html#a9179437267212bd2440a1acadf9d2b84", null ],
    [ "~DXFCurve", "class_d_x_f_curve.html#a10d9d896c5b4ccf7adac6cc418812ee8", null ],
    [ "Convert", "class_d_x_f_curve.html#af1f6e3f00be681dfb1899c4fffa41e24", null ],
    [ "Scale", "class_d_x_f_curve.html#ac9c0a03359bf840d20b9f37d34e48432", null ]
];