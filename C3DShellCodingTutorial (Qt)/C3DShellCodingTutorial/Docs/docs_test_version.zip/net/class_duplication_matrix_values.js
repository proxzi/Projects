var class_duplication_matrix_values =
[
    [ "DuplicationMatrixValues", "class_duplication_matrix_values.html#a58055db376450765faf17f0487e30f57", null ],
    [ "DuplicationMatrixValues", "class_duplication_matrix_values.html#a531f46b413fbe064f43e9c0f7167a136", null ],
    [ "DuplicationMatrixValues", "class_duplication_matrix_values.html#ac2a17abd1f05c95a66e837e469929a9a", null ],
    [ "~DuplicationMatrixValues", "class_duplication_matrix_values.html#a8f81f70e62abc41448e9bedba15e49b5", null ],
    [ "Count", "class_duplication_matrix_values.html#ad1c1e2328b494667a0c070529cb45fe4", null ],
    [ "Duplicate", "class_duplication_matrix_values.html#a5fd3cf68d3ab44f8e290f5c201d4f8cd", null ],
    [ "GenerateTransformMatrices", "class_duplication_matrix_values.html#ab3e1efbbf643eb39b3b52c4b11d25e6c", null ],
    [ "GetProperties", "class_duplication_matrix_values.html#a063bcd59ee6fda2440601b68d3281f2e", null ],
    [ "Init", "class_duplication_matrix_values.html#af6bf8de15f5a70e7e5f1bc1aeba5e3da", null ],
    [ "Init", "class_duplication_matrix_values.html#a702fb4430733d4cec10861e66043bd7c", null ],
    [ "IsSame", "class_duplication_matrix_values.html#a6b2d58d0823e25629ab39d76c9ce0df3", null ],
    [ "Move", "class_duplication_matrix_values.html#a6b910a19708d9bb4a8a90b20b82e6628", null ],
    [ "Rotate", "class_duplication_matrix_values.html#ae63837784005a2c81d5dd917f2da9cd1", null ],
    [ "SetProperties", "class_duplication_matrix_values.html#afd43a91093cabf7f4b27033b3202201d", null ],
    [ "Transform", "class_duplication_matrix_values.html#a15028a86e4f844de6ad0b55b29cea13c", null ],
    [ "Type", "class_duplication_matrix_values.html#a86d9c046ab90a23b5b8b3367d4594799", null ],
    [ "matrices", "class_duplication_matrix_values.html#a517e657f0fcf91feac3649a5b33c832d", null ]
];