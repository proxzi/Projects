var class_close_event =
[
    [ "CloseEvent", "class_close_event.html#a24363862268dc28f6a0389c981f380de", null ],
    [ "CloseEvent", "class_close_event.html#ab6d7fe777ea447db0ee569beffd987b6", null ],
    [ "~CloseEvent", "class_close_event.html#aacfc75972d4befb23a9c42577857a0f7", null ]
];