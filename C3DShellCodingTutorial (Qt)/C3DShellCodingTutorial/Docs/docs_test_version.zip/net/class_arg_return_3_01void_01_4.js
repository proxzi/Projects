var class_arg_return_3_01void_01_4 =
[
    [ "ArgReturn", "class_arg_return_3_01void_01_4.html#aa22ae3d9f3b9703ce53b387a52e7b995", null ],
    [ "SetData", "class_arg_return_3_01void_01_4.html#a3073112496ad8b659b4f7d2ba6508040", null ]
];