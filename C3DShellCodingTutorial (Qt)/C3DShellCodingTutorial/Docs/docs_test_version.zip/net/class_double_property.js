var class_double_property =
[
    [ "DoubleProperty", "class_double_property.html#a98f23bedb1c694c76b1ddbacc86847ed", null ],
    [ "~DoubleProperty", "class_double_property.html#ac44c2f2e89cb23c44d5dbdc2a9b9b6a7", null ],
    [ "_GetPropertyValue", "class_double_property.html#a7a71c625cffd765f99c64a900d9cd39c", null ],
    [ "GetCharValue", "class_double_property.html#a0ca51dd61de404163fba43843817c05f", null ],
    [ "IsA", "class_double_property.html#abd125fddeb9ea8bf2a38528f39fe4c96", null ],
    [ "SetPropertyValue", "class_double_property.html#adea16ce427fd95b729fcbaa0affca518", null ],
    [ "value", "class_double_property.html#aabdc71211c6394bd334796a9e4fb7f82", null ]
];