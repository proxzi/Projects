var class_auxiliary_data =
[
    [ "AuxiliaryData", "class_auxiliary_data.html#af483fabcdf1e067aec2e48b9e02b6215", null ],
    [ "AuxiliaryData", "class_auxiliary_data.html#a01f23d885c718452ffb8c3b9a0bd592c", null ],
    [ "~AuxiliaryData", "class_auxiliary_data.html#a85265f6f2f6ed1cb530d0c564cc05846", null ]
];