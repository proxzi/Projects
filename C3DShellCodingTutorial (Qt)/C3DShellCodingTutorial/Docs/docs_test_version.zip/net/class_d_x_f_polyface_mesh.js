var class_d_x_f_polyface_mesh =
[
    [ "DXFPolyfaceMesh", "class_d_x_f_polyface_mesh.html#a06b937c9876ba52cf98405f09c638409", null ],
    [ "~DXFPolyfaceMesh", "class_d_x_f_polyface_mesh.html#a23776bb636805646d102de2266ed7442", null ],
    [ "Convert", "class_d_x_f_polyface_mesh.html#a7f198737a43bc848e0154274fb0aa11b", null ],
    [ "Scale", "class_d_x_f_polyface_mesh.html#af5ef923bb75bf0c39bf28c9b03a02932", null ]
];