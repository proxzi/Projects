var class_dimension_geometry =
[
    [ "ArrowOrientation", "class_dimension_geometry.html#a835b8cac5beb511d24afb0376944d2fb", [
      [ "orient_Internal", "class_dimension_geometry.html#a835b8cac5beb511d24afb0376944d2fba42c55029be635d4aa835c96ce18e31cb", null ],
      [ "orient_External", "class_dimension_geometry.html#a835b8cac5beb511d24afb0376944d2fba753936ace923617eedf91bdf2e9bc301", null ],
      [ "orient_Auto", "class_dimension_geometry.html#a835b8cac5beb511d24afb0376944d2fba6383d7119599d915e86170346b460c4e", null ]
    ] ],
    [ "TextHPosition", "class_dimension_geometry.html#acbff4878d1ae03ec970e12f8b62a4597", [
      [ "hpos_Left", "class_dimension_geometry.html#acbff4878d1ae03ec970e12f8b62a4597af8da9a7916d779b0951e121557bc6836", null ],
      [ "hpos_Right", "class_dimension_geometry.html#acbff4878d1ae03ec970e12f8b62a4597a4e178134c2080905c11e58b0f4356cc6", null ],
      [ "hpos_Center", "class_dimension_geometry.html#acbff4878d1ae03ec970e12f8b62a4597af933e54cbca0780e19696d5978ac47e9", null ],
      [ "hpos_Auto", "class_dimension_geometry.html#acbff4878d1ae03ec970e12f8b62a4597a1dc4b8b44e5f8b8f3d53dc2b4da301d0", null ]
    ] ],
    [ "TextOrientation", "class_dimension_geometry.html#a93a923cf5983a8fd8834f877eed542a9", [
      [ "to_Freeze", "class_dimension_geometry.html#a93a923cf5983a8fd8834f877eed542a9aba00957a8871a311e5c2178396c95b1f", null ],
      [ "to_ScreenOnly", "class_dimension_geometry.html#a93a923cf5983a8fd8834f877eed542a9aaf903da5c848ea4f1b3c3df34dd04755", null ],
      [ "to_Readable", "class_dimension_geometry.html#a93a923cf5983a8fd8834f877eed542a9a46d29d9f1cfa22095331888025a6a36b", null ]
    ] ],
    [ "TextVPosition", "class_dimension_geometry.html#a69b2fed27dbb4564ac005034c043a369", [
      [ "vpos_Above", "class_dimension_geometry.html#a69b2fed27dbb4564ac005034c043a369af8b6dc29fc1ad169a16eea7c4a959a73", null ],
      [ "vpos_Below", "class_dimension_geometry.html#a69b2fed27dbb4564ac005034c043a369ad20a29a08834d0164d790ed190849874", null ],
      [ "vpos_Center", "class_dimension_geometry.html#a69b2fed27dbb4564ac005034c043a369a6142c8da0dfb3b9704fc5a38240949e5", null ]
    ] ],
    [ "ValueType", "class_dimension_geometry.html#acebec741359eaa62a12b00e62f0f9296", [
      [ "vt_Calculated", "class_dimension_geometry.html#acebec741359eaa62a12b00e62f0f9296a8952e5900e2581377556bb07aa439898", null ],
      [ "vt_UserDouble", "class_dimension_geometry.html#acebec741359eaa62a12b00e62f0f9296a62230513bfa99624a08be5fb0a7dcf7a", null ],
      [ "vt_UserText", "class_dimension_geometry.html#acebec741359eaa62a12b00e62f0f9296a6629e21adf47c711dd7832300f31780c", null ]
    ] ],
    [ "DimensionGeometry", "class_dimension_geometry.html#a85c4f4e0004d16de5d36872de152c4cd", null ],
    [ "~DimensionGeometry", "class_dimension_geometry.html#a3e5a18582fc3f3cac5335fab636d6f6f", null ],
    [ "DimensionGeometry", "class_dimension_geometry.html#a08d237fff5acb881b5adcb1f3903af62", null ],
    [ "CalculateValue", "class_dimension_geometry.html#a34000067b64ef7fefc7f2ca7216234e2", null ],
    [ "GetBoundingBox", "class_dimension_geometry.html#a6c4f35cd0e2592ff3178b217c14f7cf0", null ],
    [ "GetDefaultUnits", "class_dimension_geometry.html#abb4f1ee45cc0217e6c2fec6aaa5d9942", null ],
    [ "GetDimensionColor", "class_dimension_geometry.html#a27e86d02d91e5405509c077255e24dd0", null ],
    [ "GetExtensionLineHeight", "class_dimension_geometry.html#a546f096608b54eedfc12ed1145aec7be", null ],
    [ "GetFontSize", "class_dimension_geometry.html#a67ebfd14b2d4110ab6aa3208c715409e", null ],
    [ "GetLabelColor", "class_dimension_geometry.html#ae7c7ad4c3fe423294196ed4eff79a49d", null ],
    [ "GetOutputUnits", "class_dimension_geometry.html#aa2478717d52284bd57638b760242be11", null ],
    [ "GetPlane", "class_dimension_geometry.html#aa35c162e03554f0bc07adc9df184f43d", null ],
    [ "GetTextHPosition", "class_dimension_geometry.html#a6fa129b5fddb1019b1b082241e21d243", null ],
    [ "GetTextOrientation", "class_dimension_geometry.html#a9e1fc6cb898319bff7d857fba13827e9", null ],
    [ "GetTextPosition", "class_dimension_geometry.html#aaa55e28bc435920b272f23a58a64985c", null ],
    [ "GetTextVPosition", "class_dimension_geometry.html#a88dc3dd8d37cd3f4013c16972244c817", null ],
    [ "GetValue", "class_dimension_geometry.html#ae187a164ee8c4be9eede7595a7293a13", null ],
    [ "IsTextPositionUser", "class_dimension_geometry.html#a176abdabbad6ba190f9ce8132ddd3eff", null ],
    [ "IsValid", "class_dimension_geometry.html#acafc05b7ce913ca131181a48548151f2", null ],
    [ "OpenGLDraw", "class_dimension_geometry.html#ae7b5370d068e26bfc09573943f6e623b", null ],
    [ "SetDefaultUnits", "class_dimension_geometry.html#ae41dd1c58afed21ab3d16749866643d7", null ],
    [ "SetDimensionColor", "class_dimension_geometry.html#aa615c9f856b64afba3bf64bf0dab8cbc", null ],
    [ "SetExtensionLineHeight", "class_dimension_geometry.html#ae83b5cddc755a74e01167b048e8a5cdf", null ],
    [ "SetFontSize", "class_dimension_geometry.html#ad6e2bf41f57f15bb45aa81a3cf708665", null ],
    [ "SetLabelColor", "class_dimension_geometry.html#acb8266224f377dba49085ed1ca5f3984", null ],
    [ "SetOutputUnits", "class_dimension_geometry.html#aa7363ef470d8bef4f93780f91f0d221c", null ],
    [ "SetPlane", "class_dimension_geometry.html#ab029af136b7032590cf1e1316605442f", null ],
    [ "SetTextPosition", "class_dimension_geometry.html#a170ac75cc9e9dc4944772668059df0b2", null ],
    [ "VSN_DECLARE_EX_PRIVATE", "class_dimension_geometry.html#a0ab98ed48e784148db05777523f6fd83", null ]
];