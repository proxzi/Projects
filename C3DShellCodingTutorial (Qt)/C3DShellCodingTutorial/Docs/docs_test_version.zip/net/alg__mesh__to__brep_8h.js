var alg__mesh__to__brep_8h =
[
    [ "ConnectTriangleFaces", "alg__mesh__to__brep_8h.html#ab7f333f7f9f1891295a5a89a250a44a2", null ],
    [ "ConvertCollectionToShell", "alg__mesh__to__brep_8h.html#ad2406573ed9e66ea62e1226a9b7389a4", null ],
    [ "ConvertGridToShell", "alg__mesh__to__brep_8h.html#adcc19b65db7fb9e3843600688ffa4adb", null ],
    [ "ConvertMeshToShell", "alg__mesh__to__brep_8h.html#a575e0b9a24f573c8c5b2cf92e01a408d", null ],
    [ "RemoveRedundantPoints", "alg__mesh__to__brep_8h.html#a3c14f9f45aebae83208af9775656d35a", null ],
    [ "RemoveRedundantPoints", "alg__mesh__to__brep_8h.html#a464e6f21cb0cafc4926b37203b0db774", null ],
    [ "RemoveRedundantPoints", "alg__mesh__to__brep_8h.html#ae5304f28f51271601d8aaad4f6b48131", null ],
    [ "StitchAdjacentGridsEdges", "alg__mesh__to__brep_8h.html#ae017c7f7a344344091bb3fe36520e429", null ],
    [ "GridsToShellValues", "alg__mesh__to__brep_8h.html#ac531aee0fcbbb501c3f5285b774b33e3", null ],
    [ "IProgressIndicator", "alg__mesh__to__brep_8h.html#a12a620bc511339a624bad4b595ec017a", null ],
    [ "MbCartPoint3D", "alg__mesh__to__brep_8h.html#a9e84085814bc2726a5ea3d0e98e1da16", null ],
    [ "MbCollection", "alg__mesh__to__brep_8h.html#ab3b5c5b3245a16c7afa99b8b03f13ffe", null ],
    [ "MbFaceShell", "alg__mesh__to__brep_8h.html#a1bd7345c219d90f5cc184c793318f934", null ],
    [ "MbGrid", "alg__mesh__to__brep_8h.html#a346c7935a70fe5b397c074a315752651", null ],
    [ "MbMesh", "alg__mesh__to__brep_8h.html#ac5e01735c9a1a3b6dd2c4b2ea44c3c41", null ],
    [ "MbSNameMaker", "alg__mesh__to__brep_8h.html#aa8a863d55d6b75fae68ee02c9d15906e", null ],
    [ "MbTriangle", "alg__mesh__to__brep_8h.html#a6af94efe8fc4d1e040fce7afdcaa3b24", null ],
    [ "MbVector3D", "alg__mesh__to__brep_8h.html#ae51331489d453966c005aa75aeabb74f", null ],
    [ "ProgressBarWrapper", "alg__mesh__to__brep_8h.html#a94c7921928464a11359eeb0f1c5efb62", null ]
];