var class_coord_location_listener =
[
    [ "CoordLocationListener", "class_coord_location_listener.html#a1db91b76ca783e614a562491a7e3f927", null ],
    [ "~CoordLocationListener", "class_coord_location_listener.html#a046ada7fc42b2d39ac60c6ed1c41a479", null ],
    [ "GetLocation", "class_coord_location_listener.html#a770445baf8f4a9f469464006078342da", null ]
];