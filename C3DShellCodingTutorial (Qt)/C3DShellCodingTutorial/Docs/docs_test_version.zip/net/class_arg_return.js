var class_arg_return =
[
    [ "ArgReturn", "class_arg_return.html#a22f4f8e3fcc4545c1ed51cdb5747bda2", null ],
    [ "GetData", "class_arg_return.html#ad44bc9c751d5ce6e04654fd3fcfbc5d2", null ],
    [ "SetData", "class_arg_return.html#a00e4dac8dbc9c2e957673642c6c3f66c", null ]
];