var class_cosinusoid_par =
[
    [ "CosinusoidPar", "class_cosinusoid_par.html#a1ac9facfe4f98c4fe96e17876282e5a6", null ],
    [ "CosinusoidPar", "class_cosinusoid_par.html#a249cf547027292820d7d838dc2a96cbc", null ],
    [ "~CosinusoidPar", "class_cosinusoid_par.html#a13487c2477cd1e99eb45b76a23c293ea", null ],
    [ "Assign", "class_cosinusoid_par.html#ab1834e8e469446d81538d924cc4ad270", null ],
    [ "Read", "class_cosinusoid_par.html#a02229e94ab50fd97700d556f3b0629fa", null ],
    [ "Write", "class_cosinusoid_par.html#a9c9819945767404494947b44dee1d64a", null ],
    [ "m_WaveLineAmpl", "class_cosinusoid_par.html#aa4545787d97405086d5ac775ced98d53", null ],
    [ "m_WaveLineAmplByPercent", "class_cosinusoid_par.html#a36bcb0df011cd99c891c92af07123944", null ],
    [ "m_WaveLineByCount", "class_cosinusoid_par.html#a2597389ddab51f88058e0fc4e112ac38", null ],
    [ "m_WaveLineCount", "class_cosinusoid_par.html#aaa389d9b073734388fd5c3595cdb68c5", null ],
    [ "m_WaveLineDir", "class_cosinusoid_par.html#aad12abd537cde1dd76e3fb89ba3a0c74", null ],
    [ "m_WaveLineLen", "class_cosinusoid_par.html#a0525d62bdd9975208428cb94e0f7b753", null ]
];