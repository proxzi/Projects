var class_d_x_f_composite =
[
    [ "DXFComposite", "class_d_x_f_composite.html#aa1242bdd536a295ba446c4e6c27b0cfa", null ],
    [ "DXFComposite", "class_d_x_f_composite.html#a4155a3d24cac3717221ac18e5c866939", null ],
    [ "~DXFComposite", "class_d_x_f_composite.html#a606ec38d2571797761cc9160c02cbdc9", null ],
    [ "AddComposite", "class_d_x_f_composite.html#a28c0f2140266ea0e8f92a286411004d7", null ],
    [ "AddFace", "class_d_x_f_composite.html#ad4adeb4eff3797c00521fadedee82edc", null ],
    [ "AddGeometryFrom", "class_d_x_f_composite.html#a0f56a03e3cea72339d2a482195280d8d", null ],
    [ "AddGrid", "class_d_x_f_composite.html#ac5cb9a03be407743dc469606d2dc3668", null ],
    [ "AddSolidBody", "class_d_x_f_composite.html#a60cf22c570195e82e3ebeb05a9056a34", null ],
    [ "AddSpaceCurve", "class_d_x_f_composite.html#a1c6050dd5fc3f3511cc45a9b9da785b4", null ],
    [ "Complete", "class_d_x_f_composite.html#a2707432f04e6e77153c2d816a6200ab4", null ],
    [ "FlushSolidBodies", "class_d_x_f_composite.html#af6644a031df40e3d4894cf6c79c3862a", null ],
    [ "GetData", "class_d_x_f_composite.html#ace684545aead4ffc0bfe8f6f45972c4b", null ],
    [ "GetObjectsCount", "class_d_x_f_composite.html#ab7a389c7f4934153aca69378cde678f4", null ],
    [ "GetSolidBodiesCount", "class_d_x_f_composite.html#af43d7ffbf17720439e0bde3f1793792a", null ],
    [ "GetSolidBody", "class_d_x_f_composite.html#ac7a352361bd8e78a10c51431aaf05a28", null ],
    [ "IsEmpty", "class_d_x_f_composite.html#a35bf30534704353692a799a18a0be2c3", null ],
    [ "ReleaseInsert", "class_d_x_f_composite.html#a593e091323b16207267678a37070e9ee", null ],
    [ "SetSolidBody", "class_d_x_f_composite.html#ac97c65b3e92056551abbe593a07e9849", null ],
    [ "SetToModel", "class_d_x_f_composite.html#a03e2e4da091bc205346ed6294f8b9bbc", null ],
    [ "DXFCompositeRef", "class_d_x_f_composite.html#ae8bb9f7abff54b5a68fd3cc88eee0680", null ],
    [ "DXFConverter", "class_d_x_f_composite.html#a5b97a8d51b2f3c974e9887007ce24ebf", null ]
];