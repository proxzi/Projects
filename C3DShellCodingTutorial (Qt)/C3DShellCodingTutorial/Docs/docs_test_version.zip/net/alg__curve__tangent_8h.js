var alg__curve__tangent_8h =
[
    [ "MATH_FUNC", "group___curve___modeling.html#ga5bca5942a53edc8914e305fef9ba70ad", null ],
    [ "MATH_FUNC", "group___curve___modeling.html#ga3e027dce65345c71027157948522c590", null ],
    [ "MATH_FUNC", "group___curve___modeling.html#ga9c33284e03c301148abdbfdc2d288ad9", null ],
    [ "MATH_FUNC", "group___curve___modeling.html#ga99464d32bdfaaa9340daff17a1ac6404", null ],
    [ "SwapLines", "group___curve___modeling.html#gacf9919768507c188315e2640e24e7dbc", null ],
    [ "centre", "alg__curve__tangent_8h.html#af4fe7a6c3964741c235e259eafb49b47", null ],
    [ "centre2", "alg__curve__tangent_8h.html#a6fafe4b0d81f78ee6d18e26c366b9534", null ],
    [ "lineAsCurve", "alg__curve__tangent_8h.html#a29ad3bc8552b79c8b6abdb3d2812d67f", null ],
    [ "pCurve", "alg__curve__tangent_8h.html#a9a3f9e7752c9e7cd49c7c61e6cb1859d", null ],
    [ "pCurve2", "alg__curve__tangent_8h.html#ace910dedf907264613c48e65f4b5ab32", null ],
    [ "pl", "alg__curve__tangent_8h.html#ae0d0d9581502f204bc0fc0faeaace48c", null ],
    [ "pLine", "alg__curve__tangent_8h.html#ae871529465d808834b8f4d04487542ff", null ],
    [ "radius", "alg__curve__tangent_8h.html#afeaa64608c66912a9eb9f914054c1e53", null ],
    [ "radius1", "alg__curve__tangent_8h.html#ae5c64759690c00fc38460395557d2c11", null ],
    [ "radius2", "alg__curve__tangent_8h.html#aab91cdf76749aceda97a11dde8eb7de8", null ],
    [ "secodnPnt", "alg__curve__tangent_8h.html#ab445227545ec17b817061bcee8d881d1", null ],
    [ "sp", "alg__curve__tangent_8h.html#a24397099d52f9559e53812a5159ec789", null ]
];