var class_comment_rep =
[
    [ "CommentRep", "class_comment_rep.html#ac3d535a1b203e4c22ebb1511b76836fc", null ],
    [ "~CommentRep", "class_comment_rep.html#abb7ba89c2ade2b5d171101ff682b1074", null ],
    [ "ClearText", "class_comment_rep.html#aa193c1899f5c6f899192869f61b42ca9", null ],
    [ "GetTextDirection", "class_comment_rep.html#a5099dd35bf691072f55d701d5f1e874d", null ],
    [ "GetViewportIntersection", "class_comment_rep.html#adadf97109bdaf3279dfdf5bc064d1639", null ],
    [ "HideLines", "class_comment_rep.html#aea61fa00cdc624ceebe6d370c375afca", null ],
    [ "Init", "class_comment_rep.html#ab838c83d3869152e3cb529793a3c13a7", null ],
    [ "SetFontSize", "class_comment_rep.html#a1443570c2f45d24cb877d4f9b22e9b29", null ],
    [ "SetText", "class_comment_rep.html#af3a8b666aef65400dface0acf2321243", null ],
    [ "SetText", "class_comment_rep.html#ad231ed14c72f4ee41fbf706798d9ff71", null ],
    [ "SetTextDirection", "class_comment_rep.html#abab4ae9382bc3b26aea4b7c1b657d756", null ],
    [ "ShowLines", "class_comment_rep.html#a521809f418e2a9bf010a9f14d62e6f8f", null ]
];