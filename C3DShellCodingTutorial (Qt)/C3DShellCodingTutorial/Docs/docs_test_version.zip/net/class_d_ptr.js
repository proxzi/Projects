var class_d_ptr =
[
    [ "DPtr", "class_d_ptr.html#a551e777adc4c406b1471f04ef787ce02", null ],
    [ "DPtr", "class_d_ptr.html#a39cb915973dd00d4b15af6474aeb4346", null ],
    [ "DPtr", "class_d_ptr.html#a5d84e6fa55f9d6d979f14ffed94f3649", null ],
    [ "~DPtr", "class_d_ptr.html#a31695a759d419001c31365ce0409f026", null ],
    [ "operator dtype *", "class_d_ptr.html#a0fae0ff1ab0e361f0415005aff3c5304", null ],
    [ "operator!=", "class_d_ptr.html#aeb6403be3168b39bebb6322db92024f7", null ],
    [ "operator!=", "class_d_ptr.html#a16bf75b74cff6ec58ec845eea6ee0a48", null ],
    [ "operator*", "class_d_ptr.html#a7ffacd4c9e7b0cc31597555711d750ee", null ],
    [ "operator->", "class_d_ptr.html#a337810126e277ecf0210ac8e1bd6b0a6", null ],
    [ "operator=", "class_d_ptr.html#a7a2068286dff087d9ea7d0c126db0445", null ],
    [ "operator=", "class_d_ptr.html#ae0efcb27523b9967fde1aa8aeb8d0d0b", null ],
    [ "operator==", "class_d_ptr.html#a205f1ed77b7497d3ff68a316597a887d", null ],
    [ "operator==", "class_d_ptr.html#a370e84ebb510e432b9d34a8ab2d16b19", null ]
];