var class_curve_w_type =
[
    [ "CurveWType", "class_curve_w_type.html#a5102f0f880a4fd64461111564b458718", null ],
    [ "~CurveWType", "class_curve_w_type.html#a7f0cd11053c471a82c4b6bc2b7ee9681", null ],
    [ "Duplicate", "class_curve_w_type.html#a2b079dde29718880f5ee51cc7de4e27d", null ],
    [ "GetCurve", "class_curve_w_type.html#a57f38dc8b9a1a4c12d9b1d44a177dd77", null ],
    [ "GetSubType", "class_curve_w_type.html#ae847da876b5a78ad12cfaf853de8482f", null ],
    [ "GetTolerance", "class_curve_w_type.html#a82c6580528a17d83c664c1ea81ca10f6", null ],
    [ "GetType", "class_curve_w_type.html#a1fb18dad391db66665652f5dc528913b", null ],
    [ "IsHidden", "class_curve_w_type.html#a7fd88adf225f8842f8f5a6e59de2d8d6", null ],
    [ "SetHidden", "class_curve_w_type.html#a15e757c368738dc8cdae7740b17c9b0e", null ]
];