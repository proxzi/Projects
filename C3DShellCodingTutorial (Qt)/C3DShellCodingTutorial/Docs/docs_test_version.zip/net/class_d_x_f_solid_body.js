var class_d_x_f_solid_body =
[
    [ "DXFSolidBody", "class_d_x_f_solid_body.html#aa13936585081a0fb50bb2f53bc632bdb", null ],
    [ "DXFSolidBody", "class_d_x_f_solid_body.html#a120b624b0fca21ef4e86496cb755e7a7", null ],
    [ "~DXFSolidBody", "class_d_x_f_solid_body.html#a52f9ec1f14702c3bd4d8294d225c337c", null ],
    [ "AddFaces", "class_d_x_f_solid_body.html#a76cef9677c4015d691b1d42e4139e4b4", null ],
    [ "AddSolids", "class_d_x_f_solid_body.html#a2d584a4b9e21bff8d523f430b68133a8", null ],
    [ "FillSolids", "class_d_x_f_solid_body.html#aee0511903fcc3fac6a9e15b8ca88f7f0", null ],
    [ "Flush", "class_d_x_f_solid_body.html#a3b4d4c24adfed89f92d2bfa80d99a7d6", null ],
    [ "GetFaces", "class_d_x_f_solid_body.html#a3e3e69a0833da38d85c977662a6143fc", null ],
    [ "GetFacesCount", "class_d_x_f_solid_body.html#a581885fdbbea0ffb8f40a848e7c026ea", null ],
    [ "GetPlacement", "class_d_x_f_solid_body.html#adf477ab2213e1235d326eb3c50cc07fd", null ],
    [ "GetSolids", "class_d_x_f_solid_body.html#acc008c41e8a412e9669ad8cca1e2aade", null ],
    [ "GetSolidsCount", "class_d_x_f_solid_body.html#a52fc09217a9762aea32412a70dda7446", null ],
    [ "IsEmpty", "class_d_x_f_solid_body.html#af21f2014f0e6d53b6f723dc312520822", null ],
    [ "IsSingle", "class_d_x_f_solid_body.html#a01c3f56ecdea38e5ef186037c28ec9c1", null ],
    [ "MakePlacementIdentical", "class_d_x_f_solid_body.html#aa487c7eed6f090207fc37f3a07c08212", null ],
    [ "SetPlacement", "group___d_x_f___exchange.html#ga545bf0f85797b23c39123bb115399c03", null ]
];