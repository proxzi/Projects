var class_double_fields =
[
    [ "DoubleFields", "class_double_fields.html#ab8b57ea964d2a005d414dc0f117507b6", null ],
    [ "DoubleFields", "class_double_fields.html#a2e947bf968d525a95bf93013147d89b0", null ],
    [ "DoubleFields", "class_double_fields.html#a1c6f8d91e5987dbea46a62742aea6d19", null ],
    [ "GetBottom", "class_double_fields.html#a6f98cffb0bc8014c42370801dc3281bc", null ],
    [ "GetLeft", "class_double_fields.html#a94eef3c8a3c22d0007cc03b15289b5fe", null ],
    [ "GetRight", "class_double_fields.html#a4955b6501bc1fe608e65348cc4cc3b57", null ],
    [ "GetTop", "class_double_fields.html#ac77c0c6f513480761e66a70fd4ed22ff", null ],
    [ "IsNull", "class_double_fields.html#a6ca4221b28250862c7190c241f1ef67e", null ],
    [ "operator*=", "class_double_fields.html#a0e1e9fbabc02df09d71c849a2703b067", null ],
    [ "operator+=", "class_double_fields.html#a2a0b9f8ca8a3114dba994a96f1702f24", null ],
    [ "operator+=", "class_double_fields.html#a16201c941070275629fb5bc23185f63c", null ],
    [ "operator-=", "class_double_fields.html#aa4aa32e6943e1b50d9659504c36118ac", null ],
    [ "operator-=", "class_double_fields.html#aa2d2ca11560e14751169210b9cec1f89", null ],
    [ "operator/=", "class_double_fields.html#a75375338804bbd29468c1584cbf3ec36", null ],
    [ "SetBottom", "class_double_fields.html#ab58d0f15e4a89ae86cf3a3625bf862fc", null ],
    [ "SetLeft", "class_double_fields.html#ad909e3fb4147725b9c60765eceeb12a3", null ],
    [ "SetRight", "class_double_fields.html#ac58b222c4b2d0e9518de7aacc6b47865", null ],
    [ "SetTop", "class_double_fields.html#ac66d821f14b33a6dedfda6dadd1fde5c", null ],
    [ "ToFields", "class_double_fields.html#ac40cd587f3ad086dd4693b551b0d8388", null ]
];