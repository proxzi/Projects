var alg__nurbs__conic_8h =
[
    [ "MATH_FUNC", "group___curve___modeling.html#ga105e0464fe6c09ff99f84c193268d5b3", null ],
    [ "MATH_FUNC", "group___curve3_d___modeling.html#gaf3ba7abdef3109612cdcdd5fbd6f00bd", null ],
    [ "fDiscr", "alg__nurbs__conic_8h.html#ab32c4afad0252b10594cc7b9c1574a1d", null ],
    [ "MATH_FUNC", "group___curve3_d___modeling.html#ga69aa5a6db2c827fcc5ab4efe9cccbe61", null ],
    [ "mbPoint1", "alg__nurbs__conic_8h.html#acc0205fc43e607745ea9ee300c714ef2", null ],
    [ "mbPoint2", "alg__nurbs__conic_8h.html#abc6f65bd8532f296bce74356805bf54c", null ],
    [ "mbTangent1", "alg__nurbs__conic_8h.html#ac1479e1ed3610c3ed08b93734e62b25e", null ],
    [ "mbTangent2", "alg__nurbs__conic_8h.html#a03115639a7ba9f67693ed3cdfbf5e17b", null ]
];