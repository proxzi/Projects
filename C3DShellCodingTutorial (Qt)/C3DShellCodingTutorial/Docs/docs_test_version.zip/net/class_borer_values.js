var class_borer_values =
[
    [ "BorerType", "group___build___parameters.html#ga3f0b6a76e53fcd82e89e1c15e52ef309", [
      [ "bt_SimpleCylinder", "group___build___parameters.html#gga3f0b6a76e53fcd82e89e1c15e52ef309acc6b21c12d275f89563103255c522645", null ],
      [ "bt_TwofoldCylinder", "group___build___parameters.html#gga3f0b6a76e53fcd82e89e1c15e52ef309abb87aab1c94ad98c0639e3d7f0e866c5", null ],
      [ "bt_ChamferCylinder", "group___build___parameters.html#gga3f0b6a76e53fcd82e89e1c15e52ef309a6b71932aefa4c3b453e48effb6418cde", null ],
      [ "bt_ComplexCylinder", "group___build___parameters.html#gga3f0b6a76e53fcd82e89e1c15e52ef309aa7a5914952b1b76c7bebcf105b2ccdd5", null ],
      [ "bt_SimpleCone", "group___build___parameters.html#gga3f0b6a76e53fcd82e89e1c15e52ef309aa0ba8784396731f58b27dd4c70280aaf", null ],
      [ "bt_ArcCylinder", "group___build___parameters.html#gga3f0b6a76e53fcd82e89e1c15e52ef309a743d99fcc89e7773541dd0545482f87e", null ]
    ] ],
    [ "BorerValues", "class_borer_values.html#abb0407096c7fa2f8fa6e1460787cdb71", null ],
    [ "~BorerValues", "class_borer_values.html#a293c19255a302cc2ad7e68c7086a2607", null ],
    [ "Duplicate", "class_borer_values.html#a844419414eee17fc0ee6e074ae7acd55", null ],
    [ "IsSame", "class_borer_values.html#ab09f45a36bffca775283f42564406896", null ],
    [ "operator=", "class_borer_values.html#ae5a8fad85a007ff29b5319440061898b", null ],
    [ "Transform", "class_borer_values.html#af829fcb7492c6169b15e9596e5c1f5fb", null ],
    [ "Type", "class_borer_values.html#a87ec647df2f70719ff328682c32bd696", null ],
    [ "angle", "class_borer_values.html#addf92e580b4b0ebb89220cf47c2362e9", null ],
    [ "arcRadius", "class_borer_values.html#ae4b39b5492de7f967c1dc650e2142f3c", null ],
    [ "capAngle", "class_borer_values.html#ad0fde8ca597bfca95369602f09653284", null ],
    [ "capDepth", "class_borer_values.html#a71807f257a178ddeeff8349931ddbb08", null ],
    [ "capDiameter", "class_borer_values.html#a09b43dbbee8f2632f30cbb26d3a00b1b", null ],
    [ "depth", "class_borer_values.html#aba03087ab520a98b9c1dac91af2618de", null ],
    [ "diameter", "class_borer_values.html#a7da8adfbe82fca5bed94d138cceb2eac", null ],
    [ "down", "class_borer_values.html#a1189b8545999181b9091ce9c4f376360", null ],
    [ "prolong", "class_borer_values.html#ae8eb71065cae40a73c8760daa2718293", null ],
    [ "spikeAngle", "class_borer_values.html#ab6438c3490831089d8811aac3a244237", null ],
    [ "type", "class_borer_values.html#a399ce2b3a90728bfb3283192d82cad6f", null ]
];