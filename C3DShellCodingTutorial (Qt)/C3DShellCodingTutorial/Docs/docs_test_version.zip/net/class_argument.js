var class_argument =
[
    [ "Argument", "class_argument.html#ab49e5325ecdb98e41576b5a18fea5dce", null ],
    [ "Argument", "class_argument.html#abcbce48f0629f601e8073aa1f774d34e", null ],
    [ "GetData", "class_argument.html#ad8cec74371d1aeec83cc388aa7243fc9", null ],
    [ "GetTypeName", "class_argument.html#a89aa9c23abd841dca1653e5d0c22efcd", null ]
];